from h2o_wave import ui

global_nav = [
    ui.tab(name='#dashboards/red', label='Red'),
    ui.tab(name='#dashboards/blue', label='Blue'),
    ui.tab(name='#dashboards/orange', label='Orange'),
    ui.tab(name='#dashboards/cyan', label='Cyan'),
    ui.tab(name='#dashboards/grey', label='Grey'),
    ui.tab(name='#dashboards/mint', label='Mint'),
    ui.tab(name='#dashboards/purple', label='Purple'),
]
